def niceDay(args):
    greeting = args.get("greeting", "Oh well...")
    greeting = greeting+ " Have a nice day!!" 
#    print(greeting)
    print({"greeting": greeting})
